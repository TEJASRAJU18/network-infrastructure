from django.contrib import admin
from django.urls import path
from maps.views import network_page  # Change 'app1' to 'myapp' if needed

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', network_page, name='network_page'),
]
