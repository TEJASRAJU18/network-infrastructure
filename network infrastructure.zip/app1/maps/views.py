from django.shortcuts import render
from .models import MapOutput
import subprocess

def run_scripts():
    """Run the two Python scripts and store output paths in the database."""
    subprocess.run(['python', 'mobile signal level.py'])
    subprocess.run(['python', 'network bandwidth.py'])

    MapOutput.objects.update_or_create(name="Mobile Signal Map", defaults={"path": "osm_signal_choropleth_map_3_colors.html"})
    MapOutput.objects.update_or_create(name="Network Bandwidth Map", defaults={"path": "osm_network_bandwidth_heatmap_rgb.html"})

def home(request):
    run_scripts()  # Run scripts when accessing the page
    maps = MapOutput.objects.all()
    return render(request, 'maps/index.html', {'maps': maps})

def heatmap_view(request):
    return render(request, "osm_network_bandwidth_heatmap_rgb.html")

def view_map(request, filename):
    return render(request, 'maps/view.html', {'filename': f'/static/maps/{filename}'})

def network_page(request):
    return render(request, 'network_visualization.html')